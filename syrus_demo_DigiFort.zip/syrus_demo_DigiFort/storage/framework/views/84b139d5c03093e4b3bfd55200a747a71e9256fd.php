<html>
<body>
	<br>
	<br>
<form style="text-align: center;" action="<?php echo e(route('mail')); ?>">
  <button >Send Mail</button>
</form>
</body>
</html>
