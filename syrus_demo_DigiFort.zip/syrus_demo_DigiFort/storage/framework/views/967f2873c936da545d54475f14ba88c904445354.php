<!DOCTYPE html>
<html lang="en">
   <head>
    <title>CSI Workshop</title>
    <meta charset="utf-8">

    <link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/lux/bootstrap.min.css" >
   </head>
   <body>
      <div class="center">
         <?php echo $__env->yieldContent('content'); ?>
      </div>
   </body>
    
</html>